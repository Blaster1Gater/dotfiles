#!/bin/bash 

killall feh
feh --bg-fill ~/Imagens/Wall/w.png &
