#!/bin/bash
killall polybar
polybar &
