#!/usr/bin/env bash

killall feh 2>/dev/null
feh --bg-fill ~/Imagens/Wall/w.png &

