#!/usr/bin/env bash
killall polybar
polybar &
